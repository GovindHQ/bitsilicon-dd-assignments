`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 20.03.2026 21:15:01
// Design Name: 
// Module Name: sync_fifo_tb1
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module sync_fifo_tb1();

    parameter integer DATA_WIDTH = 8;
    parameter integer DEPTH = 16;
    parameter integer ADDR_WIDTH = clog2(DEPTH);

    reg [DATA_WIDTH-1:0] model_mem [0:DEPTH-1];
    integer model_wr_ptr;
    integer model_rd_ptr;
    integer model_count;
    reg [DATA_WIDTH-1:0] model_rd_data;

    reg clk, rst_n;
    reg wr_en, rd_en;
    reg [DATA_WIDTH-1:0] wr_data;
    wire [DATA_WIDTH-1:0] rd_data;
    wire wr_full;
    wire rd_empty;
    wire [ADDR_WIDTH:0] count;

    integer cycle;

    integer cov_full;
    integer cov_empty;
    integer cov_wrap;
    integer cov_simul;
    integer cov_overflow;
    integer cov_underflow;

    sync_fifo_top #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .wr_en(wr_en),
        .wr_data(wr_data),
        .wr_full(wr_full),
        .rd_en(rd_en),
        .rd_data(rd_data),
        .rd_empty(rd_empty),
        .count(count)
    );

    initial begin
        clk = 0;
        cycle = 0;
        forever begin
            #5 clk = ~clk;
            cycle = cycle + 1;
        end
    end

    always @(posedge clk) begin

        if (wr_full)
            cov_full = cov_full + 1;
        if (rd_empty)
            cov_empty = cov_empty + 1;


        if (wr_en && (model_count < DEPTH)) begin
            model_mem[model_wr_ptr] = wr_data;

            if (model_wr_ptr == DEPTH-1)
                cov_wrap = cov_wrap + 1;

            model_wr_ptr = (model_wr_ptr + 1) % DEPTH;
        end

        if (wr_en && model_count == DEPTH)
            cov_overflow = cov_overflow + 1;

        if (rd_en && (model_count > 0)) begin
            model_rd_data = model_mem[model_rd_ptr];

            if (model_rd_ptr == DEPTH-1)
                cov_wrap = cov_wrap + 1;

            model_rd_ptr = (model_rd_ptr + 1) % DEPTH;
        end

        if (rd_en && model_count == 0)
            cov_underflow = cov_underflow + 1;

        if (wr_en && rd_en)
            cov_simul = cov_simul + 1;

        // count update
        if (wr_en && !rd_en && model_count < DEPTH)
            model_count = model_count + 1;
        else if (rd_en && !wr_en && model_count > 0)
            model_count = model_count - 1;

        #1; // allow DUT to update

        if (rst_n) begin
            if (rd_en && model_count > 0) begin
                if (rd_data !== model_rd_data) begin
                    $display("ERROR at cycle %0d", cycle);
                    $display("rd_data mismatch. Expected=%0d Got=%0d", model_rd_data, rd_data);
                    $finish;
                end
            end

            if (count !== model_count) begin
                $display("ERROR at cycle %0d", cycle);
                $display("count mismatch. Expected=%0d Got=%0d", model_count, count);
                $finish;
            end

            if (rd_empty !== (model_count == 0)) begin
                $display("ERROR at cycle %0d", cycle);
                $display("rd_empty mismatch. Expected=%0d Got=%0d", model_count == 0, rd_empty);
                $finish;
            end

            if (wr_full !== (model_count == DEPTH)) begin
                $display("ERROR at cycle %0d", cycle);
                $display("wr_full mismatch. Expected=%0d Got=%0d", model_count == DEPTH, wr_full);
                $finish;
            end
        end
    end

    initial begin

        cov_full = 0;
        cov_empty = 0;
        cov_wrap = 0;
        cov_simul = 0;
        cov_overflow = 0;
        cov_underflow = 0;

        rst_n = 0;
        wr_en = 0;
        rd_en = 0;
        wr_data = 0;

        model_wr_ptr = 0;
        model_rd_ptr = 0;
        model_count  = 0;

        #13;
        rst_n = 1;

        #10;
        if (count != 0 || rd_empty != 1 || wr_full != 0) begin
            $display("RESET TEST FAILED");
            $finish;
        end
        $display("RESET TEST PASS");

        #10;
        wr_en = 1;
        wr_data = 5;
        #10;
        wr_en = 0;
        rd_en = 1;
        #10;
        if (rd_data != 5) begin
            $display("SINGLE WRITE/READ TEST FAILED");
            $finish;
        end
        $display("SINGLE WRITE/READ TEST PASSED");

        #10;
        rd_en = 0;
        for (integer i = 0; model_count < DEPTH; i = i + 1) begin
            wr_en = 1;
            wr_data = i;
            #10;
        end
        if (~wr_full) begin
            $display("FILL TEST FAILED");
            $finish;
        end
        $display("FILL TEST PASSED");

        #10;
        // attempting to write when full
        if (count != DEPTH || wr_full != 1) begin
            $display("OVERFLOW ATTEMPT TEST FAILED");
            $finish;
        end
        $display("OVERFLOW ATTEMPT TEST PASSED");

        #10;
        wr_en=0;
        for (integer i = 0; model_count > 0; i = i + 1) begin
            rd_en = 1;
            #10;
        end
        if (~rd_empty) begin
            $display("DRAIN TEST FAILED");
            $finish;
        end
        $display("DRAIN TEST PASSED");

        #10;
        // attempting to read when full
        if (count != 0 || rd_empty != 1) begin
            $display("UNDERFLOW ATTEMPT TEST FAILED");
            $finish;
        end
        $display("UNDERFLOW ATTEMPT TEST PASSED");

        // filling the FIFO
        #10;
        rd_en = 0;
        for (integer i = 0; model_count < DEPTH; i = i + 1) begin
            wr_en = 1;
            wr_data = i;
            #10;
        end
        // removing few entries
        #10;
        wr_en=0;
        for (integer i = 0; i < 3; i = i + 1) begin
            rd_en = 1;
            #10;
        end
        // forcing WRAP
        #10;
        rd_en = 0;
        for (integer i = 0; model_count < DEPTH; i = i + 1) begin
            wr_en = 1;
            wr_data = i;
            #10;
        end
        if (~wr_full) begin
            $display("WRAP TEST FAILED");
            $finish;
        end
        $display("WRAP TEST PASSED");
        
        #10;
        rd_en = 1;
        wr_en = 1;
        wr_data = 9;
        if (rd_data != model_rd_data) begin
            $display("SIMULTANEOUS READ/WRITE TEST FAILED");
            $finish;
        end
        $display("SIMULTANEOUS READ/WRITE TEST PASSED");

        $finish;
    end

endmodule
