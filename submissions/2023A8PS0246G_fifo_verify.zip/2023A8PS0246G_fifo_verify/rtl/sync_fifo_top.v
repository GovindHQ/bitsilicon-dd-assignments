`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 20.03.2026 20:33:13
// Design Name: 
// Module Name: assignment2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

function integer clog2;
    input integer value;
    integer i;
    begin
        value = value - 1;
        for (i = 0; value > 0; i = i + 1)
            value = value >> 1;
        clog2 = i;
    end
endfunction


module sync_fifo_top #(
    parameter integer DATA_WIDTH = 8,
    parameter integer DEPTH = 16,
    parameter integer ADDR_WIDTH = clog2(DEPTH)
) (
    input wire clk,
    input wire rst_n,

    input wire wr_en,
    input wire [DATA_WIDTH-1:0] wr_data,
    output wire wr_full,

    input wire rd_en,
    output reg [DATA_WIDTH-1:0] rd_data,
    output wire rd_empty,

    output wire [ADDR_WIDTH:0] count
);

    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];
    reg [ADDR_WIDTH-1:0] wr_ptr, rd_ptr;
    reg [ADDR_WIDTH:0] count_reg;

    assign count = count_reg;
    assign rd_empty = ~|count_reg;
    assign wr_full = (count_reg == DEPTH);

    always @(posedge clk) begin

        if (~rst_n) begin
            count_reg <= 0;
            rd_ptr <= 0;
            wr_ptr <= 0;
        end else begin
            if (wr_en && ~rd_en && (count_reg < DEPTH)) begin
                // write but no read
                mem[wr_ptr] <= wr_data;
                wr_ptr <= (wr_ptr == DEPTH-1) ? 0 : wr_ptr + 1;
                count_reg <= count_reg + 1;
            end

            if (~wr_en && rd_en && (count_reg > 0)) begin
                // read but no write
                rd_data <= mem[rd_ptr];
                rd_ptr <= (rd_ptr == DEPTH-1) ? 0 : rd_ptr + 1;
                count_reg <= count_reg - 1;
            end

            if (wr_en && rd_en && (count_reg < DEPTH) && (count_reg > 0)) begin
                // write and read at the same time
                mem[wr_ptr] <= wr_data;
                rd_data <= mem[rd_ptr];
                wr_ptr <= (wr_ptr == DEPTH-1) ? 0 : wr_ptr + 1;
                rd_ptr <= (rd_ptr == DEPTH-1) ? 0 : rd_ptr + 1;
            end
        end

    end

endmodule
