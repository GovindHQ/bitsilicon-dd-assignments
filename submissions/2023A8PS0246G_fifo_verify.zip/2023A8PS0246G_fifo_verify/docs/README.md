## OVERVIEW
implemented and tested a FIFO module in verilog, vivado

### ISSUES
By mistake instead of creating `fifo` module and `fifo_top` module seperately i misread and implemented both together in one module

Rest everything seems to be working fine !