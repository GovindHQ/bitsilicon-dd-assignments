// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb.h for the primary calling header

#include "Vtb__pch.h"

VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf);
VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__1(Vtb___024root* vlSelf);

void Vtb___024root___eval_initial(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vtb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vtb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
}

VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__0\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.tb__DOT__reset = 0U;
    vlSelfRef.tb__DOT__start = 0U;
    vlSelfRef.tb__DOT__stop = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x0000000000002710ULL, 
                                         nullptr, "tb.v", 
                                         51);
    vlSelfRef.tb__DOT__reset = 1U;
    vlSelfRef.tb__DOT__start = 1U;
    vlSelfRef.tb__DOT__stop = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x000000000001fbd0ULL, 
                                         nullptr, "tb.v", 
                                         56);
    vlSelfRef.tb__DOT__reset = 1U;
    vlSelfRef.tb__DOT__start = 0U;
    vlSelfRef.tb__DOT__stop = 1U;
    co_await vlSelfRef.__VdlySched.delay(0x0000000000004e20ULL, 
                                         nullptr, "tb.v", 
                                         61);
    vlSelfRef.tb__DOT__reset = 1U;
    vlSelfRef.tb__DOT__start = 1U;
    vlSelfRef.tb__DOT__stop = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x00000000000186a0ULL, 
                                         nullptr, "tb.v", 
                                         66);
    vlSelfRef.tb__DOT__reset = 1U;
    vlSelfRef.tb__DOT__start = 0U;
    vlSelfRef.tb__DOT__stop = 1U;
    co_await vlSelfRef.__VdlySched.delay(0x0000000000004e20ULL, 
                                         nullptr, "tb.v", 
                                         71);
    vlSelfRef.tb__DOT__reset = 1U;
    vlSelfRef.tb__DOT__start = 1U;
    vlSelfRef.tb__DOT__stop = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x0000000000030d40ULL, 
                                         nullptr, "tb.v", 
                                         76);
    vlSelfRef.tb__DOT__reset = 0U;
    vlSelfRef.tb__DOT__start = 0U;
    vlSelfRef.tb__DOT__stop = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x0000000000004e20ULL, 
                                         nullptr, "tb.v", 
                                         81);
    vlSelfRef.tb__DOT__reset = 1U;
    vlSelfRef.tb__DOT__start = 1U;
    vlSelfRef.tb__DOT__stop = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x00000000000249f0ULL, 
                                         nullptr, "tb.v", 
                                         86);
    vlSelfRef.tb__DOT__reset = 0U;
    vlSelfRef.tb__DOT__start = 0U;
    vlSelfRef.tb__DOT__stop = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x000000000000c350ULL, 
                                         nullptr, "tb.v", 
                                         91);
    vlSelfRef.tb__DOT__reset = 1U;
    vlSelfRef.tb__DOT__start = 1U;
    vlSelfRef.tb__DOT__stop = 0U;
    co_await vlSelfRef.__VdlySched.delay(0x00000000004c4b40ULL, 
                                         nullptr, "tb.v", 
                                         96);
    VL_WRITEF_NX("%3# : %2#\n",0,8,vlSelfRef.tb__DOT__minutes,
                 6,(IData)(vlSelfRef.tb__DOT__seconds));
    VL_FINISH_MT("tb.v", 98, "");
    co_return;}

VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__1(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__1\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (VL_LIKELY(!vlSymsp->_vm_contextp__->gotFinish())) {
        vlSelfRef.tb__DOT__clk = 0U;
        co_await vlSelfRef.__VdlySched.delay(0x0000000000001388ULL, 
                                             nullptr, 
                                             "tb.v", 
                                             104);
        vlSelfRef.tb__DOT__clk = 1U;
        co_await vlSelfRef.__VdlySched.delay(0x0000000000001388ULL, 
                                             nullptr, 
                                             "tb.v", 
                                             105);
    }
    co_return;}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

void Vtb___024root___eval_triggers__act(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_triggers__act\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered[0U] = (QData)((IData)(
                                                    ((vlSelfRef.__VdlySched.awaitingCurrentTime() 
                                                      << 2U) 
                                                     | ((((~ (IData)(vlSelfRef.tb__DOT__reset)) 
                                                          & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__reset__0)) 
                                                         << 1U) 
                                                        | ((IData)(vlSelfRef.tb__DOT__clk) 
                                                           & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__clk__0)))))));
    vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__clk__0 
        = vlSelfRef.tb__DOT__clk;
    vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__reset__0 
        = vlSelfRef.tb__DOT__reset;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
}

bool Vtb___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___trigger_anySet__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void Vtb___024root___nba_sequent__TOP__0(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___nba_sequent__TOP__0\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*1:0*/ __Vdly__tb__DOT__swt__DOT__cfsm__DOT__state;
    __Vdly__tb__DOT__swt__DOT__cfsm__DOT__state = 0;
    CData/*1:0*/ __VdlyMask__tb__DOT__swt__DOT__cfsm__DOT__state;
    __VdlyMask__tb__DOT__swt__DOT__cfsm__DOT__state = 0;
    CData/*0:0*/ __Vdly__tb__DOT__swt__DOT__min_w;
    __Vdly__tb__DOT__swt__DOT__min_w = 0;
    CData/*5:0*/ __Vdly__tb__DOT__seconds;
    __Vdly__tb__DOT__seconds = 0;
    CData/*5:0*/ __VdlyMask__tb__DOT__seconds;
    __VdlyMask__tb__DOT__seconds = 0;
    CData/*7:0*/ __Vdly__tb__DOT__minutes;
    __Vdly__tb__DOT__minutes = 0;
    CData/*7:0*/ __VdlyMask__tb__DOT__minutes;
    __VdlyMask__tb__DOT__minutes = 0;
    // Body
    __Vdly__tb__DOT__swt__DOT__min_w = 0U;
    if (vlSelfRef.tb__DOT__reset) {
        if (vlSelfRef.tb__DOT__swt__DOT__sec_w) {
            if ((0x3bU == (IData)(vlSelfRef.tb__DOT__seconds))) {
                vlSelfRef.tb__DOT__seconds = 0U;
                vlSelfRef.tb__DOT__swt__DOT__min_w = 1U;
            } else {
                __Vdly__tb__DOT__seconds = (0x0000003fU 
                                            & ((IData)(1U) 
                                               + (IData)(vlSelfRef.tb__DOT__seconds)));
                __VdlyMask__tb__DOT__seconds = 0x3fU;
            }
        }
        if ((0U == (IData)(vlSelfRef.tb__DOT__swt__DOT__cfsm__DOT__state))) {
            vlSelfRef.tb__DOT__status = 0U;
            if (vlSelfRef.tb__DOT__start) {
                vlSelfRef.tb__DOT__status = 1U;
                vlSelfRef.tb__DOT__swt__DOT__cfsm__DOT__state = 1U;
            }
        } else if ((1U == (IData)(vlSelfRef.tb__DOT__swt__DOT__cfsm__DOT__state))) {
            if (vlSelfRef.tb__DOT__stop) {
                vlSelfRef.tb__DOT__status = 2U;
                __Vdly__tb__DOT__swt__DOT__cfsm__DOT__state = 2U;
                __VdlyMask__tb__DOT__swt__DOT__cfsm__DOT__state = 3U;
            } else {
                vlSelfRef.tb__DOT__swt__DOT__sec_w = 1U;
            }
        } else if ((2U == (IData)(vlSelfRef.tb__DOT__swt__DOT__cfsm__DOT__state))) {
            vlSelfRef.tb__DOT__swt__DOT__sec_w = 0U;
            if (vlSelfRef.tb__DOT__start) {
                vlSelfRef.tb__DOT__status = 1U;
                vlSelfRef.tb__DOT__swt__DOT__cfsm__DOT__state = 1U;
            }
        } else {
            __Vdly__tb__DOT__swt__DOT__cfsm__DOT__state = 0U;
            __VdlyMask__tb__DOT__swt__DOT__cfsm__DOT__state = 3U;
        }
        if (vlSelfRef.tb__DOT__swt__DOT__min_w) {
            vlSelfRef.tb__DOT__minutes = (0x000000ffU 
                                          & ((IData)(1U) 
                                             + (IData)(vlSelfRef.tb__DOT__minutes)));
            if ((0x64U == (IData)(vlSelfRef.tb__DOT__minutes))) {
                __Vdly__tb__DOT__minutes = 0U;
                __VdlyMask__tb__DOT__minutes = 0xffU;
            }
        }
    } else {
        __Vdly__tb__DOT__seconds = 0U;
        __VdlyMask__tb__DOT__seconds = 0x3fU;
        vlSelfRef.tb__DOT__swt__DOT__cfsm__DOT__state = 0U;
        vlSelfRef.tb__DOT__status = 0U;
        vlSelfRef.tb__DOT__swt__DOT__sec_w = 0U;
        __Vdly__tb__DOT__minutes = 0U;
        __VdlyMask__tb__DOT__minutes = 0xffU;
    }
    vlSelfRef.tb__DOT__seconds = (((IData)(__Vdly__tb__DOT__seconds) 
                                   & (IData)(__VdlyMask__tb__DOT__seconds)) 
                                  | ((IData)(vlSelfRef.tb__DOT__seconds) 
                                     & (~ (IData)(__VdlyMask__tb__DOT__seconds))));
    __VdlyMask__tb__DOT__seconds = 0U;
    vlSelfRef.tb__DOT__swt__DOT__cfsm__DOT__state = 
        (((IData)(__Vdly__tb__DOT__swt__DOT__cfsm__DOT__state) 
          & (IData)(__VdlyMask__tb__DOT__swt__DOT__cfsm__DOT__state)) 
         | ((IData)(vlSelfRef.tb__DOT__swt__DOT__cfsm__DOT__state) 
            & (~ (IData)(__VdlyMask__tb__DOT__swt__DOT__cfsm__DOT__state))));
    __VdlyMask__tb__DOT__swt__DOT__cfsm__DOT__state = 0U;
    vlSelfRef.tb__DOT__swt__DOT__min_w = __Vdly__tb__DOT__swt__DOT__min_w;
    vlSelfRef.tb__DOT__minutes = (((IData)(__Vdly__tb__DOT__minutes) 
                                   & (IData)(__VdlyMask__tb__DOT__minutes)) 
                                  | ((IData)(vlSelfRef.tb__DOT__minutes) 
                                     & (~ (IData)(__VdlyMask__tb__DOT__minutes))));
    __VdlyMask__tb__DOT__minutes = 0U;
}

void Vtb___024root___eval_nba(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_nba\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vtb___024root___nba_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[1U] = 1U;
    }
}

void Vtb___024root___timing_resume(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___timing_resume\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((4ULL & vlSelfRef.__VactTriggered[0U])) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vtb___024root___trigger_orInto__act(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___trigger_orInto__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

bool Vtb___024root___eval_phase__act(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_phase__act\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VactExecute;
    // Body
    Vtb___024root___eval_triggers__act(vlSelf);
    Vtb___024root___trigger_orInto__act(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    __VactExecute = Vtb___024root___trigger_anySet__act(vlSelfRef.__VactTriggered);
    if (__VactExecute) {
        Vtb___024root___timing_resume(vlSelf);
    }
    return (__VactExecute);
}

void Vtb___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___trigger_clear__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

bool Vtb___024root___eval_phase__nba(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_phase__nba\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = Vtb___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        Vtb___024root___eval_nba(vlSelf);
        Vtb___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

void Vtb___024root___eval(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VnbaIterCount;
    // Body
    __VnbaIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00000064U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vtb___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
            VL_FATAL_MT("tb.v", 23, "", "DIDNOTCONVERGE: NBA region did not converge after '--converge-limit' of 100 tries");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        vlSelfRef.__VactIterCount = 0U;
        do {
            if (VL_UNLIKELY(((0x00000064U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                Vtb___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
                VL_FATAL_MT("tb.v", 23, "", "DIDNOTCONVERGE: Active region did not converge after '--converge-limit' of 100 tries");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactPhaseResult = Vtb___024root___eval_phase__act(vlSelf);
        } while (vlSelfRef.__VactPhaseResult);
        vlSelfRef.__VnbaPhaseResult = Vtb___024root___eval_phase__nba(vlSelf);
    } while (vlSelfRef.__VnbaPhaseResult);
}

#ifdef VL_DEBUG
void Vtb___024root___eval_debug_assertions(Vtb___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_debug_assertions\n"); );
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
