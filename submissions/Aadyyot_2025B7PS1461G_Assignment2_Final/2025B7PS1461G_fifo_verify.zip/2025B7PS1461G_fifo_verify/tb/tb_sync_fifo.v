`timescale 1ns/1ps

module tb_sync_fifo;

    parameter integer DATA_WIDTH = 8;
    parameter integer DEPTH      = 16;

    function integer clog2;
        input integer value;
        integer i;
        begin
            value = value - 1;
            for (i = 0; value > 0; i = i + 1)
                value = value >> 1;
            clog2 = i;
        end
    endfunction

    localparam integer ADDR_WIDTH = clog2(DEPTH);

    // ------------------------------------------------------------
    // DUT interface signals
    // ------------------------------------------------------------
    reg                   clk;
    reg                   rst_n;
    reg                   wr_en;
    reg  [DATA_WIDTH-1:0] wr_data;
    wire                  wr_full;
    reg                   rd_en;
    wire [DATA_WIDTH-1:0] rd_data;
    wire                  rd_empty;
    wire [ADDR_WIDTH:0]   count;

    // ------------------------------------------------------------
    // Instantiate DUT
    // ------------------------------------------------------------
    sync_fifo_top #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .wr_en(wr_en),
        .wr_data(wr_data),
        .wr_full(wr_full),
        .rd_en(rd_en),
        .rd_data(rd_data),
        .rd_empty(rd_empty),
        .count(count)
    );

    // ------------------------------------------------------------
    // Bookkeeping
    // ------------------------------------------------------------
    integer cycle;
    integer seed;
    reg [255:0] test_name;

    // ------------------------------------------------------------
    // Manual Coverage Counters
    // ------------------------------------------------------------
    integer cov_full;
    integer cov_empty;
    integer cov_wrap;
    integer cov_simul;
    integer cov_overflow;
    integer cov_underflow;

    // ------------------------------------------------------------
    // Golden Reference Model
    // ------------------------------------------------------------
    reg [DATA_WIDTH-1:0] model_mem [0:DEPTH-1];
    integer model_wr_ptr;
    integer model_rd_ptr;
    integer model_count;
    reg [DATA_WIDTH-1:0] model_rd_data;

    reg                  prev_rd_valid;
    reg [DATA_WIDTH-1:0] expected_rd_data;

    // ------------------------------------------------------------
    // Clock generation
    // ------------------------------------------------------------
    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    // ------------------------------------------------------------
    // Cycle counter
    // ------------------------------------------------------------
    always @(posedge clk) begin
        cycle <= cycle + 1;
    end

    // ------------------------------------------------------------
    // Golden model update
    // Must use its own state, not DUT outputs
    // ------------------------------------------------------------
    always @(posedge clk) begin
        if (!rst_n) begin
            model_wr_ptr     <= 0;
            model_rd_ptr     <= 0;
            model_count      <= 0;
            model_rd_data    <= 0;
            prev_rd_valid    <= 1'b0;
            expected_rd_data <= 0;
        end
        else begin
            prev_rd_valid <= (rd_en && (model_count > 0));

            if (rd_en && (model_count > 0))
                expected_rd_data <= model_mem[model_rd_ptr];

            // Coverage: illegal ops
            if (wr_en && (model_count == DEPTH))
                cov_overflow <= cov_overflow + 1;

            if (rd_en && (model_count == 0))
                cov_underflow <= cov_underflow + 1;

            // Coverage: simultaneous valid read/write
            if ((wr_en && (model_count < DEPTH)) &&
                (rd_en && (model_count > 0)))
                cov_simul <= cov_simul + 1;

            // Valid write
            if (wr_en && (model_count < DEPTH)) begin
                model_mem[model_wr_ptr] <= wr_data;

                if (model_wr_ptr == DEPTH-1) begin
                    model_wr_ptr <= 0;
                    cov_wrap <= cov_wrap + 1;
                end
                else begin
                    model_wr_ptr <= model_wr_ptr + 1;
                end
            end

            // Valid read
            if (rd_en && (model_count > 0)) begin
                model_rd_data <= model_mem[model_rd_ptr];

                if (model_rd_ptr == DEPTH-1) begin
                    model_rd_ptr <= 0;
                    cov_wrap <= cov_wrap + 1;
                end
                else begin
                    model_rd_ptr <= model_rd_ptr + 1;
                end
            end

            // Count update
            case ({(wr_en && (model_count < DEPTH)),
                   (rd_en && (model_count > 0))})
                2'b10: model_count <= model_count + 1;
                2'b01: model_count <= model_count - 1;
                2'b11: model_count <= model_count;
                default: model_count <= model_count;
            endcase

            // Coverage: reaching full and empty
            if ((model_count == DEPTH-1) && (wr_en && (model_count < DEPTH)))
                cov_full <= cov_full + 1;

            if ((model_count == 1) && (rd_en && (model_count > 0)))
                cov_empty <= cov_empty + 1;
        end
    end

    // ------------------------------------------------------------
    // Scoreboard
    // Compare after DUT/model updates settle
    // ------------------------------------------------------------
    always @(posedge clk) begin
        #1;
        if (rst_n) begin
            if (count !== model_count) begin
                $display("ERROR at cycle %0d", cycle);
                $display("Time = %0t", $time);
                $display("Test name = %0s", test_name);
                $display("Seed value = %0d", seed);
                $display("Expected count = %0d, Got = %0d", model_count, count);
                $display("Inputs: wr_en=%0b rd_en=%0b wr_data=0x%0h", wr_en, rd_en, wr_data);
                $display("Model ptrs: wr_ptr=%0d rd_ptr=%0d", model_wr_ptr, model_rd_ptr);
                $finish;
            end

            if (rd_empty !== (model_count == 0)) begin
                $display("ERROR at cycle %0d", cycle);
                $display("Time = %0t", $time);
                $display("Test name = %0s", test_name);
                $display("Seed value = %0d", seed);
                $display("Expected rd_empty = %0b, Got = %0b", (model_count == 0), rd_empty);
                $display("Inputs: wr_en=%0b rd_en=%0b wr_data=0x%0h", wr_en, rd_en, wr_data);
                $display("Model ptrs: wr_ptr=%0d rd_ptr=%0d", model_wr_ptr, model_rd_ptr);
                $finish;
            end

            if (wr_full !== (model_count == DEPTH)) begin
                $display("ERROR at cycle %0d", cycle);
                $display("Time = %0t", $time);
                $display("Test name = %0s", test_name);
                $display("Seed value = %0d", seed);
                $display("Expected wr_full = %0b, Got = %0b", (model_count == DEPTH), wr_full);
                $display("Inputs: wr_en=%0b rd_en=%0b wr_data=0x%0h", wr_en, rd_en, wr_data);
                $display("Model ptrs: wr_ptr=%0d rd_ptr=%0d", model_wr_ptr, model_rd_ptr);
                $finish;
            end

            if (prev_rd_valid) begin
                if (rd_data !== expected_rd_data) begin
                    $display("ERROR at cycle %0d", cycle);
                    $display("Time = %0t", $time);
                    $display("Test name = %0s", test_name);
                    $display("Seed value = %0d", seed);
                    $display("Expected rd_data = 0x%0h, Got = 0x%0h", expected_rd_data, rd_data);
                    $display("Inputs: wr_en=%0b rd_en=%0b wr_data=0x%0h", wr_en, rd_en, wr_data);
                    $display("Model ptrs: wr_ptr=%0d rd_ptr=%0d", model_wr_ptr, model_rd_ptr);
                    $finish;
                end
            end
        end
    end

    // ------------------------------------------------------------
    // Utility tasks
    // ------------------------------------------------------------
    task init_inputs;
        begin
            wr_en   = 1'b0;
            rd_en   = 1'b0;
            wr_data = {DATA_WIDTH{1'b0}};
        end
    endtask

    task apply_reset;
        begin
            rst_n = 1'b1;
            init_inputs();
            @(posedge clk);
            rst_n = 1'b0;
            @(posedge clk);
            @(posedge clk);
            rst_n = 1'b1;
            @(posedge clk);
        end
    endtask

    task do_write;
        input [DATA_WIDTH-1:0] data_in;
        begin
            @(negedge clk);
            wr_en   = 1'b1;
            rd_en   = 1'b0;
            wr_data = data_in;
            @(negedge clk);
            wr_en   = 1'b0;
            wr_data = {DATA_WIDTH{1'b0}};
        end
    endtask

    task do_read;
        begin
            @(negedge clk);
            wr_en = 1'b0;
            rd_en = 1'b1;
            @(negedge clk);
            rd_en = 1'b0;
        end
    endtask

    // ------------------------------------------------------------
    // Directed Tests
    // ------------------------------------------------------------
    task reset_test;
        begin
            test_name = "Reset Test";
            apply_reset();

            if (count !== 0 || rd_empty !== 1'b1 || wr_full !== 1'b0) begin
                $display("ERROR in Reset Test");
                $finish;
            end

            $display("PASS: Reset Test");
        end
    endtask

    task single_write_read_test;
        begin
            test_name = "Single Write / Read Test";
            apply_reset();

            do_write(8'hA5);

            if (count !== 1) begin
                $display("ERROR in Single Write / Read Test: count should be 1 after write");
                $finish;
            end

            do_read();

            if (count !== 0) begin
                $display("ERROR in Single Write / Read Test: count should be 0 after read");
                $finish;
            end

            $display("PASS: Single Write / Read Test");
        end
    endtask

    task fill_test;
        integer i;
        reg [ADDR_WIDTH:0] prev_count;
        begin
            test_name = "Fill Test";
            apply_reset();

            for (i = 0; i < DEPTH; i = i + 1)
                do_write(i[DATA_WIDTH-1:0]);

            if (count !== DEPTH || wr_full !== 1'b1) begin
                $display("ERROR in Fill Test");
                $finish;
            end

            prev_count = count;
            do_write(8'hFF);

            if (count !== prev_count) begin
                $display("ERROR in Fill Test: extra write changed state");
                $finish;
            end

            $display("PASS: Fill Test");
        end
    endtask

    task drain_test;
        integer i;
        begin
            test_name = "Drain Test";
            apply_reset();

            for (i = 0; i < DEPTH; i = i + 1)
                do_write((i + 8'h10));

            for (i = 0; i < DEPTH; i = i + 1)
                do_read();

            if (count !== 0 || rd_empty !== 1'b1) begin
                $display("ERROR in Drain Test");
                $finish;
            end

            $display("PASS: Drain Test");
        end
    endtask

    task overflow_attempt_test;
        integer i;
        reg [ADDR_WIDTH:0] prev_count;
        begin
            test_name = "Overflow Attempt Test";
            apply_reset();

            for (i = 0; i < DEPTH; i = i + 1)
                do_write(i[DATA_WIDTH-1:0]);

            prev_count = count;
            do_write(8'hEE);

            if (count !== prev_count || wr_full !== 1'b1) begin
                $display("ERROR in Overflow Attempt Test");
                $finish;
            end

            $display("PASS: Overflow Attempt Test");
        end
    endtask

    task underflow_attempt_test;
        reg [DATA_WIDTH-1:0] prev_data;
        begin
            test_name = "Underflow Attempt Test";
            apply_reset();

            prev_data = rd_data;
            do_read();

            if (count !== 0 || rd_empty !== 1'b1 || rd_data !== prev_data) begin
                $display("ERROR in Underflow Attempt Test");
                $finish;
            end

            $display("PASS: Underflow Attempt Test");
        end
    endtask

    task simultaneous_rw_test;
        begin
            test_name = "Simultaneous Read / Write Test";
            apply_reset();

            do_write(8'h11);
            do_write(8'h22);
            do_write(8'h33);

            @(negedge clk);
            wr_en   = 1'b1;
            rd_en   = 1'b1;
            wr_data = 8'h44;
            @(negedge clk);
            wr_en   = 1'b0;
            rd_en   = 1'b0;
            wr_data = 8'h00;

            if (count !== 3) begin
                $display("ERROR in Simultaneous Read / Write Test");
                $finish;
            end

            $display("PASS: Simultaneous Read / Write Test");
        end
    endtask

    task pointer_wrap_test;
        integer i;
        begin
            test_name = "Pointer Wrap-Around Test";
            apply_reset();

            for (i = 0; i < DEPTH; i = i + 1)
                do_write(i[DATA_WIDTH-1:0]);

            for (i = 0; i < DEPTH/2; i = i + 1)
                do_read();

            for (i = 0; i < DEPTH/2; i = i + 1)
                do_write((i + 8'h80));

            for (i = 0; i < DEPTH; i = i + 1)
                do_read();

            if (count !== 0 || rd_empty !== 1'b1) begin
                $display("ERROR in Pointer Wrap-Around Test");
                $finish;
            end

            $display("PASS: Pointer Wrap-Around Test");
        end
    endtask

    // ------------------------------------------------------------
    // Main simulation
    // ------------------------------------------------------------
    initial begin
        cycle = 0;
        seed  = 32'h1234ABCD;

        cov_full      = 0;
        cov_empty     = 0;
        cov_wrap      = 0;
        cov_simul     = 0;
        cov_overflow  = 0;
        cov_underflow = 0;

        rst_n = 1'b1;
        init_inputs();

        reset_test();
        single_write_read_test();
        fill_test();
        drain_test();
        overflow_attempt_test();
        underflow_attempt_test();
        simultaneous_rw_test();
        pointer_wrap_test();

        $display("======================================");
        $display("ALL DIRECTED TESTS PASSED");
        $display("Coverage Summary:");
        $display("cov_full      = %0d", cov_full);
        $display("cov_empty     = %0d", cov_empty);
        $display("cov_wrap      = %0d", cov_wrap);
        $display("cov_simul     = %0d", cov_simul);
        $display("cov_overflow  = %0d", cov_overflow);
        $display("cov_underflow = %0d", cov_underflow);
        $display("======================================");

        $finish;
    end

endmodule