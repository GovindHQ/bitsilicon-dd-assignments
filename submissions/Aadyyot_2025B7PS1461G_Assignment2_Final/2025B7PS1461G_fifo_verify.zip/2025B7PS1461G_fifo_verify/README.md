# Synchronous FIFO Verification Assignment

## Files
- rtl/sync_fifo_top.v
- rtl/sync_fifo.v
- tb/tb_sync_fifo.v
- docs/README.md

## DUT Summary
Implemented synchronous FIFO with:
- memory array
- write pointer
- read pointer
- occupancy counter
- full/empty flags derived from count

## Verification Summary
Implemented self-checking testbench with:
- golden reference model
- explicit scoreboard
- failure reporting
- directed tests
- manual coverage counters

## Directed Tests
- Reset Test
- Single Write / Read Test
- Fill Test
- Drain Test
- Overflow Attempt Test
- Underflow Attempt Test
- Simultaneous Read/Write Test
- Pointer Wrap-Around Test

## Coverage Counters
- cov_full
- cov_empty
- cov_wrap
- cov_simul
- cov_overflow
- cov_underflow