module sync_fifo_top (
    clk,
    rst_n,      // active-low synchronous reset
    wr_en,
    wr_data,
    wr_full,
    rd_en,
    rd_data,
    rd_empty,
    count
);

    parameter integer DATA_WIDTH = 8;
    parameter integer DEPTH      = 16;

    // ------------------------------------------------------------
    // Function to compute ADDR_WIDTH = clog2(DEPTH)
    // ------------------------------------------------------------
    function integer clog2;
        input integer value;
        integer i;
        begin
            value = value - 1;
            for (i = 0; value > 0; i = i + 1)
                value = value >> 1;
            clog2 = i;
        end
    endfunction

    localparam integer ADDR_WIDTH = clog2(DEPTH);

    // ------------------------------------------------------------
    // Port declarations
    // ------------------------------------------------------------
    input  wire                  clk;
    input  wire                  rst_n;
    input  wire                  wr_en;
    input  wire [DATA_WIDTH-1:0] wr_data;
    output wire                  wr_full;
    input  wire                  rd_en;
    output reg  [DATA_WIDTH-1:0] rd_data;
    output wire                  rd_empty;
    output wire [ADDR_WIDTH:0]   count;

    // ------------------------------------------------------------
    // Internal Hardware Structure
    // ------------------------------------------------------------
    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];
    reg [ADDR_WIDTH-1:0] wr_ptr;
    reg [ADDR_WIDTH-1:0] rd_ptr;
    reg [ADDR_WIDTH:0]   count_reg;

    wire write_valid;
    wire read_valid;

    assign write_valid = wr_en && (count_reg < DEPTH);
    assign read_valid  = rd_en && (count_reg > 0);

    // ------------------------------------------------------------
    // Full and empty flags derived from occupancy counter
    // ------------------------------------------------------------
    assign rd_empty = (count_reg == 0);
    assign wr_full  = (count_reg == DEPTH);
    assign count    = count_reg;

    // ------------------------------------------------------------
    // All operations occur on the rising edge of clk
    // ------------------------------------------------------------
    always @(posedge clk) begin
        if (!rst_n) begin
            // Reset behavior
            wr_ptr    <= {ADDR_WIDTH{1'b0}};
            rd_ptr    <= {ADDR_WIDTH{1'b0}};
            count_reg <= {(ADDR_WIDTH+1){1'b0}};
            rd_data   <= {DATA_WIDTH{1'b0}};
        end
        else begin
            // Write operation
            if (write_valid) begin
                mem[wr_ptr] <= wr_data;
                if (wr_ptr == DEPTH-1)
                    wr_ptr <= {ADDR_WIDTH{1'b0}};
                else
                    wr_ptr <= wr_ptr + 1'b1;
            end

            // Read operation
            if (read_valid) begin
                rd_data <= mem[rd_ptr];
                if (rd_ptr == DEPTH-1)
                    rd_ptr <= {ADDR_WIDTH{1'b0}};
                else
                    rd_ptr <= rd_ptr + 1'b1;
            end

            // Count update
            case ({write_valid, read_valid})
                2'b10: count_reg <= count_reg + 1'b1; // write only
                2'b01: count_reg <= count_reg - 1'b1; // read only
                2'b11: count_reg <= count_reg;        // simultaneous read/write
                default: count_reg <= count_reg;      // no valid op
            endcase
        end
    end

endmodule