module sync_fifo (
    clk,
    rst_n,
    wr_en,
    wr_data,
    wr_full,
    rd_en,
    rd_data,
    rd_empty,
    count
);

    parameter integer DATA_WIDTH = 8;
    parameter integer DEPTH      = 16;

    function integer clog2;
        input integer value;
        integer i;
        begin
            value = value - 1;
            for (i = 0; value > 0; i = i + 1)
                value = value >> 1;
            clog2 = i;
        end
    endfunction

    localparam integer ADDR_WIDTH = clog2(DEPTH);

    input  wire                  clk;
    input  wire                  rst_n;
    input  wire                  wr_en;
    input  wire [DATA_WIDTH-1:0] wr_data;
    output wire                  wr_full;
    input  wire                  rd_en;
    output wire [DATA_WIDTH-1:0] rd_data;
    output wire                  rd_empty;
    output wire [ADDR_WIDTH:0]   count;

    sync_fifo_top #(
        .DATA_WIDTH(DATA_WIDTH),
        .DEPTH(DEPTH)
    ) u_sync_fifo_top (
        .clk(clk),
        .rst_n(rst_n),
        .wr_en(wr_en),
        .wr_data(wr_data),
        .wr_full(wr_full),
        .rd_en(rd_en),
        .rd_data(rd_data),
        .rd_empty(rd_empty),
        .count(count)
    );

endmodule